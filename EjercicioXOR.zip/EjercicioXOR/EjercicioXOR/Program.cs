﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioXOR
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] datos = { { 0, 0 }, { 0, 1 }, { 1, 0 }, { 1, 1 } };
            int[] salidas = { 0, 1, 1, 0 }; 
            double[] pesos = { 0, 0 };
            double umbral = 0.5; 
            double tasaAprendizaje = 0.1; 

            int numIteraciones = 0;
            int maxNumIteraciones = 10000;
            bool error = true;

            while (error && numIteraciones < maxNumIteraciones)
            {
                error = false;

                for (int i = 0; i < datos.GetLength(0); i++)
                {
                    double suma = 0;

                    for (int j = 0; j < pesos.Length; j++)
                    {
                        suma += datos[i, j] * pesos[j];
                    }

                    suma -= umbral;



                    int salidaObtenida = (suma >= 0) ? 1 : 0;

                    if (salidaObtenida != salidas[i])
                    {
                        error = true;

                        for (int j = 0; j < pesos.Length; j++)
                        {
                            pesos[j] += tasaAprendizaje * (salidas[i] - salidaObtenida) * datos[i, j];
                        }

                        umbral -= tasaAprendizaje * (salidas[i] - salidaObtenida);
                    }
                }

                numIteraciones++;
            }


            ///

            for (int i = 0; i < 10000; i++) // 10,000 iteraciones
            {
                for (int j = 0; j < datos.GetLength(0); j++)
                {
                    double[] inputs = { datos[j, 0], datos[j, 1], 1 }; // entrada más bias
                    double output = CalculateOutput(inputs, pesos); // salida calculada
                    double error1 = datos[j, 2] - output; // error de predicción
                    pesos[0] += tasaAprendizaje * error1 * inputs[0]; // actualizar peso 1
                    pesos[1] += tasaAprendizaje * error1 * inputs[1]; // actualizar peso 2
                    pesos[2] += tasaAprendizaje * error1 * inputs[2]; // actualizar bias
                }
            }
            Console.WriteLine("0 XOR 0 = " + Predict(0, 0, pesos));
            Console.WriteLine("0 XOR 1 = " + Predict(0, 1, pesos));
            Console.WriteLine("1 XOR 0 = " + Predict(1, 0, pesos));
            Console.WriteLine("1 XOR 1 = " + Predict(1, 1, pesos));

            static double CalculateOutput(double[] inputs, double[] pesos)
            {
                double sum = 0;
                for (int i = 0; i < inputs.Length; i++)
                {
                    sum += inputs[i] * pesos[i];
                }
                return sum > 0 ? 1 : 0; // función de activación escalón
            }
            static int Predict(int x1, int x2, double[] pesos)
            {
                double output = CalculateOutput(new double[] { x1, x2, 1 }, pesos);
                return (int)output;
            }

            //

            Console.WriteLine("Pesos finales:");

            for (int i = 0; i < pesos.Length; i++)
            {
                Console.WriteLine("w" + i + " = " + pesos[i]);
            }

            Console.WriteLine("Umbral final: " + umbral);

            Console.ReadLine();
        }
    }

}
            
        
